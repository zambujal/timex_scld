
-- VHDL Instantiation Created from source file SCLD.vhd -- 18:41:19 08/01/2025
--
-- Notes: 
-- 1) This instantiation template has been automatically generated using types
-- std_logic and std_logic_vector for the ports of the instantiated module
-- 2) To use this template to instantiate this entity, cut-and-paste and then edit

	COMPONENT SCLD
	PORT(
		SCLD_CLK : IN std_logic;
		A_i : IN std_logic_vector(15 downto 0);
		D_i : IN std_logic_vector(7 downto 0);
		KB_i : IN std_logic_vector(4 downto 0);
		TPIN_i : IN std_logic;
		MREQ_i : IN std_logic;
		IORQ_i : IN std_logic;
		RD_i : IN std_logic;
		WR_i : IN std_logic;
		RFSH_i : IN std_logic;
		P5060_i : IN std_logic;
		BE_i : IN std_logic;          
		RAS_o : OUT std_logic;
		CAS_o : OUT std_logic;
		TS_o : OUT std_logic;
		RDN_o : OUT std_logic;
		MUX_o : OUT std_logic;
		CAS2_o : OUT std_logic;
		CAS1_o : OUT std_logic;
		MWE_o : OUT std_logic;
		CPUCLK_o : OUT std_logic;
		CPUCLKB_o : OUT std_logic;
		CSYNC_o : OUT std_logic;
		TPOUT_o : OUT std_logic;
		MA_o : OUT std_logic_vector(7 downto 0);
		MA_oe_o : OUT std_logic;
		R_o : OUT std_logic;
		G_o : OUT std_logic;
		B_o : OUT std_logic;
		BRIGHT_o : OUT std_logic;
		A7RB_o : OUT std_logic;
		ROMCS_o : OUT std_logic;
		ROSCS_o : OUT std_logic;
		EXROM_o : OUT std_logic;
		EPROM_CE_o : OUT std_logic;
		AYCLK_o : OUT std_logic;
		BC1_o : OUT std_logic;
		BDIR_o : OUT std_logic;
		D_o : OUT std_logic_vector(7 downto 0);
		D_oe_o : OUT std_logic;
		INT_oe_o : OUT std_logic;
		HSYNC_o : OUT std_logic;
		VSYNC_o : OUT std_logic
		);
	END COMPONENT;

	Inst_SCLD: SCLD PORT MAP(
		SCLD_CLK => ,
		A_i => ,
		D_i => ,
		KB_i => ,
		TPIN_i => ,
		MREQ_i => ,
		IORQ_i => ,
		RD_i => ,
		WR_i => ,
		RFSH_i => ,
		P5060_i => ,
		BE_i => ,
		RAS_o => ,
		CAS_o => ,
		TS_o => ,
		RDN_o => ,
		MUX_o => ,
		CAS2_o => ,
		CAS1_o => ,
		MWE_o => ,
		CPUCLK_o => ,
		CPUCLKB_o => ,
		CSYNC_o => ,
		TPOUT_o => ,
		MA_o => ,
		MA_oe_o => ,
		R_o => ,
		G_o => ,
		B_o => ,
		BRIGHT_o => ,
		A7RB_o => ,
		ROMCS_o => ,
		ROSCS_o => ,
		EXROM_o => ,
		EPROM_CE_o => ,
		AYCLK_o => ,
		BC1_o => ,
		BDIR_o => ,
		D_o => ,
		D_oe_o => ,
		INT_oe_o => ,
		HSYNC_o => ,
		VSYNC_o => 
	);


